/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.equestion1;

/**
 * Question 1 - Furniture Storage Customer Report
 * This application generates a customer report over a two-year period
 * Using single and two-dimensional arrays
 * 
 * @author Apex User
 */

// ========== Q.1.2 INTERFACE ==========
interface IFurnitureStorage {
    int getTotalCustomers();
    double getAverageCustomers();
    String getMostPopularTown();
    String getLeastPopularTown();
}

// ========== Q.1.2 FURNITURE STORAGE CLASS ==========
class FurnitureStorage implements IFurnitureStorage {
    // Two-dimensional array to store customer data [year][town]
    private int[][] customerData;
    // Single-dimensional array for town names
    private String[] townNames;
    private int numberOfYears;
    private int numberOfTowns;
    
    // Constructor
    public FurnitureStorage(int[][] data, String[] towns) {
        this.customerData = data;
        this.townNames = towns;
        this.numberOfYears = data.length;
        this.numberOfTowns = towns.length;
    }
    
    // Method to get total customers across all years and towns
    @Override
    public int getTotalCustomers() {
        int total = 0;
        // Using nested loops to iterate through 2D array
        for (int year = 0; year < numberOfYears; year++) {
            for (int town = 0; town < numberOfTowns; town++) {
                total += customerData[year][town];
            }
        }
        return total;
    }
    
    // Method to calculate average customers per year
    @Override
    public double getAverageCustomers() {
        int total = getTotalCustomers();
        return (double) total / numberOfYears;
    }
    
    // Method to find town with most customers across both years
    @Override
    public String getMostPopularTown() {
        int[] townTotals = new int[numberOfTowns];
        
        // Calculate total customers per town across both years
        for (int town = 0; town < numberOfTowns; town++) {
            int total = 0;
            for (int year = 0; year < numberOfYears; year++) {
                total += customerData[year][town];
            }
            townTotals[town] = total;
        }
        
        // Find town with maximum customers
        int maxIndex = 0;
        for (int i = 1; i < townTotals.length; i++) {
            if (townTotals[i] > townTotals[maxIndex]) {
                maxIndex = i;
            }
        }
        
        return townNames[maxIndex];
    }
    
    // Method to find town with least customers across both years
    @Override
    public String getLeastPopularTown() {
        int[] townTotals = new int[numberOfTowns];
        
        // Calculate total customers per town across both years
        for (int town = 0; town < numberOfTowns; town++) {
            int total = 0;
            for (int year = 0; year < numberOfYears; year++) {
                total += customerData[year][town];
            }
            townTotals[town] = total;
        }
        
        // Find town with minimum customers
        int minIndex = 0;
        for (int i = 1; i < townTotals.length; i++) {
            if (townTotals[i] < townTotals[minIndex]) {
                minIndex = i;
            }
        }
        
        return townNames[minIndex];
    }
    
    // Additional method to get data for a specific year and town
    public int getCustomerCount(int year, int town) {
        return customerData[year][town];
    }
    
    // Method to get total per year
    public int getTotalPerYear(int year) {
        int total = 0;
        for (int town = 0; town < numberOfTowns; town++) {
            total += customerData[year][town];
        }
        return total;
    }
}

// ========== Q.1.3 PRINT FURNITURE STORAGE CLASS ==========
class PrintFurnitureStorage {
    private FurnitureStorage storage;
    private String[] townNames;
    private String[] yearNames;
    
    public PrintFurnitureStorage(FurnitureStorage storage, String[] towns, String[] years) {
        this.storage = storage;
        this.townNames = towns;
        this.yearNames = years;
    }
    
    // Method to print the complete report with rows and columns
    public void printReport() {
        System.out.println("=".repeat(60));
        System.out.println("     FURNITURE STORAGE CUSTOMER REPORT");
        System.out.println("=".repeat(60));
        System.out.println();
        
        // Print header row with town names
        printTableHeader();
        
        // Print data rows for each year
        printTableData();
        
        System.out.println();
        printTotalCustomers();
        System.out.println();
        printAverageCustomers();
        System.out.println();
        printMostPopularTown();
        System.out.println();
        printLeastPopularTown();
        System.out.println();
        System.out.println("=".repeat(60));
        System.out.println("                   END OF REPORT");
        System.out.println("=".repeat(60));
    }
    
    // Method to print table header
    private void printTableHeader() {
        System.out.printf("%-15s", "Location");
        for (String town : townNames) {
            System.out.printf("%-15s", town);
        }
        System.out.printf("%-15s\n", "Total");
    }
    
    // Method to print table data (rows and columns)
    private void printTableData() {
        for (int year = 0; year < yearNames.length; year++) {
            System.out.printf("%-15s", yearNames[year]);
            int yearTotal = 0;
            
            for (int town = 0; town < townNames.length; town++) {
                int count = storage.getCustomerCount(year, town);
                System.out.printf("%-15d", count);
                yearTotal += count;
            }
            
            System.out.printf("%-15d\n", yearTotal);
        }
    }
    
    // Method to print total number of customers
    public void printTotalCustomers() {
        int total = storage.getTotalCustomers();
        System.out.println(" TOTAL NUMBER OF CUSTOMERS:");
        System.out.println("   Over the two-year period: " + total + " customers");
        System.out.println("   - Year 1 total: " + storage.getTotalPerYear(0) + " customers");
        System.out.println("   - Year 2 total: " + storage.getTotalPerYear(1) + " customers");
    }
    
    // Method to print average number of customers
    public void printAverageCustomers() {
        double average = storage.getAverageCustomers();
        System.out.println(" AVERAGE NUMBER OF CUSTOMERS:");
        System.out.printf("   Average per year: %.2f customers\n", average);
    }
    
    // Method to print town with most customers
    public void printMostPopularTown() {
        String mostPopular = storage.getMostPopularTown();
        System.out.println(" TOWN WITH MOST CUSTOMERS:");
        System.out.println("   " + mostPopular);
    }
    
    // Method to print town with least customers
    public void printLeastPopularTown() {
        String leastPopular = storage.getLeastPopularTown();
        System.out.println(" TOWN WITH LEAST CUSTOMERS:");
        System.out.println("   " + leastPopular);
    }
}

// ========== Q.1.1 MAIN CLASS ==========
public class Equestion1 {
    public static void main(String[] args) {
        System.out.println();
        System.out.println("╔════════════════════════════════════════════════════════╗");
        System.out.println("║     FURNITURE STORAGE CUSTOMER REPORT SYSTEM          ║");
        System.out.println("╚════════════════════════════════════════════════════════╝");
        System.out.println();
        
        // ========== Q.1.1 DECLARATION OF ARRAYS ==========
        
        // SINGLE-DIMENSIONAL ARRAY for town names
        String[] towns = {"CAPE TOWN", "DURBAN", "PORT ELIZABETH"};
        
        // SINGLE-DIMENSIONAL ARRAY for year labels
        String[] years = {"YEAR 1", "YEAR 2"};
        
        // TWO-DIMENSIONAL ARRAY for customer data [year][town]
        // Data as per the supplied dataset:
        // CAPE TOWN    DURBAN    PORT ELIZABETH
        // YEAR 1: 90,   15,      50
        // YEAR 2: 125,  55,      91
        int[][] customerData = {
            {90, 15, 50},   // YEAR 1 data: Cape Town, Durban, Port Elizabeth
            {125, 55, 91}   // YEAR 2 data: Cape Town, Durban, Port Elizabeth
        };
        
        // Create FurnitureStorage object (implements interface)
        FurnitureStorage storage = new FurnitureStorage(customerData, towns);
        
        // Create PrintFurnitureStorage object for printing
        PrintFurnitureStorage printer = new PrintFurnitureStorage(storage, towns, years);
        
        // Print the complete report
        printer.printReport();
        
        // Additional summary statistics
        System.out.println();
        System.out.println(" SUMMARY STATISTICS:");
        System.out.println("   Total customers Year 1: " + storage.getTotalPerYear(0));
        System.out.println("   Total customers Year 2: " + storage.getTotalPerYear(1));
        System.out.println("   Difference: " + (storage.getTotalPerYear(1) - storage.getTotalPerYear(0)) + " customers");
        
        System.out.println();
        System.out.println(" Report generated successfully using:");
        System.out.println("  - Single-dimensional arrays (towns, years)");
        System.out.println("  - Two-dimensional array (customer data)");
        System.out.println("  - IFurnitureStorage interface");
        System.out.println("  - FurnitureStorage class");
        System.out.println("  - PrintFurnitureStorage class");
    }
}