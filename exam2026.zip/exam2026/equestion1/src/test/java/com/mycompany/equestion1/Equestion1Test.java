/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.equestion1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Test Class for Question 1 - Furniture Storage System
 * Tests the FurnitureStorage class methods
 * 
 * @author Apex User
 */
public class Equestion1Test {
    
    private FurnitureStorage storage;
    private int[][] testData;
    private String[] towns;
    
    public Equestion1Test() {
    }
    
    @BeforeAll
    public static void setUpClass() {
        System.out.println("Starting FurnitureStorage Unit Tests");
    }
    
    @AfterAll
    public static void tearDownClass() {
        System.out.println("FurnitureStorage Unit Tests Completed.");
    }
    
    @BeforeEach
    public void setUp() {
        // Initialize test data before each test
        towns = new String[]{"CAPE TOWN", "DURBAN", "PORT ELIZABETH"};
        
        // Two-dimensional array with the supplied dataset
        testData = new int[][]{
            {90, 15, 50},   // YEAR 1
            {125, 55, 91}   // YEAR 2
        };
        
        storage = new FurnitureStorage(testData, towns);
    }
    
    @AfterEach
    public void tearDown() {
        storage = null;
    }

    /**
     * TEST 1: Test getTotalCustomers() method
     * Verifies that total customers across both years is calculated correctly
     */
    @Test
    public void testGetTotalCustomers() {
        System.out.println("Testing: getTotalCustomers()");
        
        int expectedTotal = 426; // 90+15+50+125+55+91 = 426
        int actualTotal = storage.getTotalCustomers();
        
        assertEquals(expectedTotal, actualTotal, 
            "Total customers should be 426 for the two-year period");
        
        System.out.println("  ✓ Expected: " + expectedTotal + ", Actual: " + actualTotal);
    }
    
    /**
     * TEST 2: Test getAverageCustomers() method
     * Verifies that average customers per year is calculated correctly
     */
    @Test
    public void testGetAverageCustomers() {
        System.out.println("Testing: getAverageCustomers()");
        
        double expectedAverage = 213.0; // 426 / 2 = 213
        double actualAverage = storage.getAverageCustomers();
        
        assertEquals(expectedAverage, actualAverage, 0.001,
            "Average customers per year should be 213.0");
        
        System.out.println("  ✓ Expected: " + expectedAverage + ", Actual: " + actualAverage);
    }
    
    /**
     * TEST 3: Test getMostPopularTown() method
     * Verifies that Cape Town is identified as the most popular town
     */
    @Test
    public void testGetMostPopularTown() {
        System.out.println("Testing: getMostPopularTown()");
        
        String expectedTown = "CAPE TOWN";
        String actualTown = storage.getMostPopularTown();
        
        assertEquals(expectedTown, actualTown,
            "Cape Town should be the most popular town with 215 customers (90+125)");
        
        System.out.println("  ✓ Expected: " + expectedTown + ", Actual: " + actualTown);
    }
    
    /**
     * TEST 4: Test getLeastPopularTown() method
     * Verifies that Durban is identified as the least popular town
     */
    @Test
    public void testGetLeastPopularTown() {
        System.out.println("Testing: getLeastPopularTown()");
        
        String expectedTown = "DURBAN";
        String actualTown = storage.getLeastPopularTown();
        
        assertEquals(expectedTown, actualTown,
            "Durban should be the least popular town with 70 customers (15+55)");
        
        System.out.println("  ✓ Expected: " + expectedTown + ", Actual: " + actualTown);
    }
    
    /**
     * TEST 5: Test getCustomerCount() method for specific year and town
     * Verifies individual data points are correct
     */
    @Test
    public void testGetCustomerCount() {
        System.out.println("Testing: getCustomerCount()");
        
        // Test Year 1, Cape Town
        assertEquals(90, storage.getCustomerCount(0, 0), 
            "Year 1, Cape Town should be 90");
        
        // Test Year 1, Durban
        assertEquals(15, storage.getCustomerCount(0, 1),
            "Year 1, Durban should be 15");
        
        // Test Year 1, Port Elizabeth
        assertEquals(50, storage.getCustomerCount(0, 2),
            "Year 1, Port Elizabeth should be 50");
        
        // Test Year 2, Cape Town
        assertEquals(125, storage.getCustomerCount(1, 0),
            "Year 2, Cape Town should be 125");
        
        // Test Year 2, Durban
        assertEquals(55, storage.getCustomerCount(1, 1),
            "Year 2, Durban should be 55");
        
        // Test Year 2, Port Elizabeth
        assertEquals(91, storage.getCustomerCount(1, 2),
            "Year 2, Port Elizabeth should be 91");
        
        System.out.println("  ✓ All data points verified correctly");
    }
    
    /**
     * TEST 6: Test getTotalPerYear() method
     * Verifies yearly totals are calculated correctly
     */
    @Test
    public void testGetTotalPerYear() {
        System.out.println("Testing: getTotalPerYear()");
        
        // Year 1 total: 90 + 15 + 50 = 155
        assertEquals(155, storage.getTotalPerYear(0),
            "Year 1 total should be 155");
        
        // Year 2 total: 125 + 55 + 91 = 271
        assertEquals(271, storage.getTotalPerYear(1),
            "Year 2 total should be 271");
        
        System.out.println("  ✓ Year 1: 155, Year 2: 271");
    }
    
    /**
     * TEST 7: Test that total is greater than individual year totals
     */
    @Test
    public void testTotalIsGreaterThanYearlyTotals() {
        System.out.println("Testing: Total > Individual Year Totals");
        
        int total = storage.getTotalCustomers();
        int year1Total = storage.getTotalPerYear(0);
        int year2Total = storage.getTotalPerYear(1);
        
        assertTrue(total > year1Total, "Total should be greater than Year 1 total");
        assertTrue(total > year2Total, "Total should be greater than Year 2 total");
        
        System.out.println("  ✓ Total (" + total + ") > Year 1 (" + year1Total + ")");
        System.out.println("  ✓ Total (" + total + ") > Year 2 (" + year2Total + ")");
    }
    
    /**
     * TEST 8: Test that average is between min and max
     */
    @Test
    public void testAverageIsBetweenMinAndMax() {
        System.out.println("Testing: Average between min and max");
        
        double average = storage.getAverageCustomers();
        int year1Total = storage.getTotalPerYear(0);
        int year2Total = storage.getTotalPerYear(1);
        int minYear = Math.min(year1Total, year2Total);
        int maxYear = Math.max(year1Total, year2Total);
        
        assertTrue(average >= minYear && average <= maxYear,
            "Average should be between the minimum and maximum yearly totals");
        
        System.out.println("  ✓ Average (" + average + ") is between " + minYear + " and " + maxYear);
    }
}