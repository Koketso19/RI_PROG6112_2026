/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.equestion2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Apex User
 */

// ICalculations Interface
interface ICalculations {
    double getVat();
    double getTotal();
}

// Calculations Class implementing ICalculations
class Calculations implements ICalculations {
    private double price;
    private int duration;
    
    public Calculations(double price, int duration) {
        this.price = price;
        this.duration = duration;
    }
    
    @Override
    public double getVat() {
        return price * 0.15;
    }
    
    @Override
    public double getTotal() {
        return (price + getVat()) * duration;
    }
}

// ARRAY CLASS FOR BACKEND STORAGE
class CustomerDataStorage {
    private String[] customerNames;
    private int[] durations;
    private double[] prices;
    private double[] vatAmounts;
    private double[] totalAmounts;
    private int recordCount;
    private static final int MAX_RECORDS = 100;
    
    public CustomerDataStorage() {
        customerNames = new String[MAX_RECORDS];
        durations = new int[MAX_RECORDS];
        prices = new double[MAX_RECORDS];
        vatAmounts = new double[MAX_RECORDS];
        totalAmounts = new double[MAX_RECORDS];
        recordCount = 0;
    }
    
    public void addCustomer(String name, int duration, double price, double vat, double total) {
        if (recordCount < MAX_RECORDS) {
            customerNames[recordCount] = name;
            durations[recordCount] = duration;
            prices[recordCount] = price;
            vatAmounts[recordCount] = vat;
            totalAmounts[recordCount] = total;
            recordCount++;
        }
    }
    
    public double calculateTotalRevenue() {
        double total = 0;
        for (int i = 0; i < recordCount; i++) {
            total += totalAmounts[i];
        }
        return total;
    }
    
    public int getRecordCount() { return recordCount; }
}

// Main GUI Class
class FurnitureStorageGUI extends JFrame {
    private JTextField nameField;
    private JComboBox<String> durationCombo;
    private JTextField priceField;
    private JTextArea displayArea;
    private JButton processButton;
    private JButton saveButton;
    private JMenuBar menuBar;
    private JMenu fileMenu;
    private JMenu toolsMenu;
    private JMenuItem exitMenuItem;
    private JMenuItem processMenuItem;
    private JMenuItem saveMenuItem;
    
    private CustomerDataStorage dataStorage;
    
    public FurnitureStorageGUI() {
        dataStorage = new CustomerDataStorage();
        
        setTitle("Furniture Storage");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 500);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
        initComponents();
        createMenuSystem();
        
        setVisible(true);
    }
    
    private void initComponents() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("Furniture Storage");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setBounds(150, 20, 200, 30);
        mainPanel.add(titleLabel);
        
        JLabel nameLabel = new JLabel("Customer Name:");
        nameLabel.setBounds(50, 80, 120, 25);
        mainPanel.add(nameLabel);
        
        nameField = new JTextField();
        nameField.setBounds(180, 80, 200, 25);
        mainPanel.add(nameField);
        
        JLabel durationLabel = new JLabel("Duration:");
        durationLabel.setBounds(50, 120, 120, 25);
        mainPanel.add(durationLabel);
        
        String[] durations = {"3", "6", "12"};
        durationCombo = new JComboBox<>(durations);
        durationCombo.setBounds(180, 120, 200, 25);
        mainPanel.add(durationCombo);
        
        JLabel priceLabel = new JLabel("Price:");
        priceLabel.setBounds(50, 160, 120, 25);
        mainPanel.add(priceLabel);
        
        priceField = new JTextField();
        priceField.setBounds(180, 160, 200, 25);
        mainPanel.add(priceField);
        
        processButton = new JButton("PROCESS");
        processButton.setBounds(100, 210, 100, 30);
        mainPanel.add(processButton);
        
        saveButton = new JButton("SAVE");
        saveButton.setBounds(230, 210, 100, 30);
        mainPanel.add(saveButton);
        
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBounds(50, 260, 350, 180);
        mainPanel.add(scrollPane);
        
        add(mainPanel, BorderLayout.CENTER);
        
        processButton.addActionListener(e -> processData());
        saveButton.addActionListener(e -> saveToFile());
    }
    
    private void createMenuSystem() {
        menuBar = new JMenuBar();
        
        fileMenu = new JMenu("File");
        exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitMenuItem);
        
        toolsMenu = new JMenu("Tools");
        processMenuItem = new JMenuItem("Process");
        processMenuItem.addActionListener(e -> processData());
        saveMenuItem = new JMenuItem("Save");
        saveMenuItem.addActionListener(e -> saveToFile());
        toolsMenu.add(processMenuItem);
        toolsMenu.add(saveMenuItem);
        
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        
        setJMenuBar(menuBar);
    }
    
    private void processData() {
        String customerName = nameField.getText().trim();
        String durationStr = (String) durationCombo.getSelectedItem();
        String priceStr = priceField.getText().trim();
        
        int duration = Integer.parseInt(durationStr);
        
        if (customerName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter customer name!");
            return;
        }
        
        if (priceStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter price!");
            return;
        }
        
        double price;
        try {
            price = Double.parseDouble(priceStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid price!");
            return;
        }
        
        Calculations calc = new Calculations(price, duration);
        double vatAmount = calc.getVat();
        double totalAmount = calc.getTotal();
        
        // Add to array (backend)
        dataStorage.addCustomer(customerName, duration, price, vatAmount, totalAmount);
        
        String output = "====================================\n" +
                       "Customer Name: " + customerName + "\n" +
                       "Storage Duration: " + duration + " months\n" +
                       "Price: R" + String.format("%.2f", price) + "\n" +
                       "VAT : R" + String.format("%.2f", vatAmount) + "\n" +
                       "====================================\n" +
                       "Total Amount: R" + String.format("%.2f", totalAmount) + "\n" +
                       "====================================";
        
        displayArea.setText(output);
        
        JOptionPane.showMessageDialog(this, output, "Customer Info", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void saveToFile() {
        String data = displayArea.getText();
        
        if (data.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No data to save! Process something first.");
            return;
        }
        
        try {
            FileWriter fw = new FileWriter("data.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw);
            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            out.println("Saved: " + sdf.format(new Date()));
            out.println(data);
            out.println("------------------------------------");
            out.println();
            out.close();
            
            JOptionPane.showMessageDialog(this, "Data saved successfully to data.txt!");
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving: " + e.getMessage());
        }
    }
}

// Main class
public class Equestion2 {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FurnitureStorageGUI());
    }
}