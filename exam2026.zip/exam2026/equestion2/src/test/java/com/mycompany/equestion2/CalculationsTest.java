/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.equestion2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * UNIT TEST CLASS for Calculations
 * Q.2.6 - Required unit tests for VAT and Total calculations
 * 
 * @author Apex User
 */
public class CalculationsTest {
    
    private Calculations calculations;
    
    public CalculationsTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
        System.out.println("Starting Calculations Unit Tests...");
    }
    
    @AfterAll
    public static void tearDownClass() {
        System.out.println("Calculations Unit Tests Completed.");
    }
    
    @BeforeEach
    public void setUp() {
        // Initialize with test data before each test
        calculations = new Calculations(1000.0, 3);
    }
    
    @AfterEach
    public void tearDown() {
        // Clean up after each test
        calculations = null;
    }

    /**
     * UNIT TEST 1
     * Test Name: getVat_WithValidData_ReturnsCorrectValue()
     * Test Purpose: Verify that the GetVat method in the Calculations class 
     * correctly returns the VAT amount (15% of price)
     */
    @Test
    public void getVat_WithValidData_ReturnsCorrectValue() {
        System.out.println("Running test: getVat_WithValidData_ReturnsCorrectValue");
        
        // Test Case 1: Price = 1000
        Calculations calc1 = new Calculations(1000.0, 3);
        double expectedVat1 = 150.0;  // 15% of 1000
        double actualVat1 = calc1.getVat();
        assertEquals(expectedVat1, actualVat1, 0.001, 
            "VAT for R1000 should be R150");
        
        // Test Case 2: Price = 500
        Calculations calc2 = new Calculations(500.0, 6);
        double expectedVat2 = 75.0;   // 15% of 500
        double actualVat2 = calc2.getVat();
        assertEquals(expectedVat2, actualVat2, 0.001,
            "VAT for R500 should be R75");
        
        // Test Case 3: Price = 200.50
        Calculations calc3 = new Calculations(200.50, 12);
        double expectedVat3 = 30.075; // 15% of 200.50
        double actualVat3 = calc3.getVat();
        assertEquals(expectedVat3, actualVat3, 0.001,
            "VAT for R200.50 should be R30.075");
        
        // Test Case 4: Price = 0
        Calculations calc4 = new Calculations(0.0, 3);
        double expectedVat4 = 0.0;
        double actualVat4 = calc4.getVat();
        assertEquals(expectedVat4, actualVat4, 0.001,
            "VAT for R0 should be R0");
        
        System.out.println("  ✓ getVat_WithValidData_ReturnsCorrectValue PASSED");
    }

    /**
     * UNIT TEST 2
     * Test Name: getTotal_WithValidData_ReturnsCorrectValue()
     * Test Purpose: Verify that the GetTotal method in the Calculations class 
     * correctly returns the total amount using formula: (Price + VAT) * Duration
     */
    @Test
    public void getTotal_WithValidData_ReturnsCorrectValue() {
        System.out.println("Running test: getTotal_WithValidData_ReturnsCorrectValue");
        
        // Test Case 1: Price = 1000, Duration = 3
        // Total = (1000 + 150) * 3 = 3450
        Calculations calc1 = new Calculations(1000.0, 3);
        double expectedTotal1 = 3450.0;
        double actualTotal1 = calc1.getTotal();
        assertEquals(expectedTotal1, actualTotal1, 0.001,
            "Total for R1000, 3 months should be R3450");
        
        // Test Case 2: Price = 500, Duration = 6
        // Total = (500 + 75) * 6 = 3450
        Calculations calc2 = new Calculations(500.0, 6);
        double expectedTotal2 = 3450.0;
        double actualTotal2 = calc2.getTotal();
        assertEquals(expectedTotal2, actualTotal2, 0.001,
            "Total for R500, 6 months should be R3450");
        
        // Test Case 3: Price = 200, Duration = 12
        // Total = (200 + 30) * 12 = 2760
        Calculations calc3 = new Calculations(200.0, 12);
        double expectedTotal3 = 2760.0;
        double actualTotal3 = calc3.getTotal();
        assertEquals(expectedTotal3, actualTotal3, 0.001,
            "Total for R200, 12 months should be R2760");
        
        // Test Case 4: Price = 1000, Duration = 1
        // Total = (1000 + 150) * 1 = 1150
        Calculations calc4 = new Calculations(1000.0, 1);
        double expectedTotal4 = 1150.0;
        double actualTotal4 = calc4.getTotal();
        assertEquals(expectedTotal4, actualTotal4, 0.001,
            "Total for R1000, 1 month should be R1150");
        
        System.out.println("  ✓ getTotal_WithValidData_ReturnsCorrectValue PASSED");
    }
}